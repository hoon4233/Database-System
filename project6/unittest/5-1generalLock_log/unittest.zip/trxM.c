#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

int count = 0;

typedef struct lock_t {
	int a;
    struct lock_t * next;
    struct lock_t * prev;
}lock_t;

typedef struct trx{
    int id;
    lock_t * first_obj;
    struct trx * prev;
    struct trx * next;
}trx;

typedef struct trxManager{
    int global_trx_id;
    trx * head_trx;
}trxManager;

trxManager * trxM;

void init_trxM(void){
    trxM = (trxManager*)malloc(sizeof(trxManager));
    trxM->global_trx_id = 1;
    trxM->head_trx = NULL;
}

void print_trxM(void){
    printf("IN print_trxM, now global_trx_id : %d\n",trxM->global_trx_id);
    trx * tmp_ptr = trxM->head_trx;

    while(tmp_ptr != NULL){
        printf("trx id : %d\n",tmp_ptr->id);
        lock_t * tmp_ptr2 = tmp_ptr->first_obj;
        while(tmp_ptr2 != NULL){
            printf("%d  ",tmp_ptr2->a);
            tmp_ptr2 = tmp_ptr2->next;
        }
        printf("\n\n");
        tmp_ptr = tmp_ptr->next;
    }
}

trx * trx_find(int trx_id){
    trx * tmp_ptr = trxM->head_trx;
    if(tmp_ptr == NULL){
        return NULL;
    }
    while(tmp_ptr != NULL){
        if(tmp_ptr->id == trx_id){
            return tmp_ptr;
        }
        tmp_ptr = tmp_ptr->next;
    }
    return NULL;
}

int trx_begin(void){
    trx * tmp_trx = (trx*)malloc(sizeof(trx));
    
    if(tmp_trx == NULL){
        return 0;
    }

    tmp_trx->id = trxM->global_trx_id; //trx 만들기
    tmp_trx->first_obj = NULL;   
    tmp_trx->prev = NULL;
    tmp_trx->next =NULL;

    trxM->global_trx_id += 1;

    trx * tmp_ptr = trxM->head_trx; //trx를 trxM에 넣기
    
    if(tmp_ptr == NULL){ //trxM에 처음 trx를 넣는 경우
        trxM->head_trx = tmp_trx;
    }

    else{  //trxM에서 linked list 구조를 이용해 마지막에 넣어주는 경우
        while(tmp_ptr->next != NULL){
            tmp_ptr = tmp_ptr->next;
        }
        tmp_ptr->next = tmp_trx;
        tmp_trx->prev = tmp_ptr;
    }

    return tmp_trx->id;
}

int trx_commit(int trx_id){
    trx * tar_trx = trx_find(trx_id);
    printf("IN trx_commit, trx_find succ, id : %d\n",tar_trx->id);
    if(tar_trx == NULL){
        return 0;
    }
    //lock release 전부 해주고 (trx의 lock obj 없애주기)
    lock_t * tmp_ptr = tar_trx->first_obj;
    if(tmp_ptr != NULL){  //obj를 가지고 있다면
        while(tmp_ptr->next != NULL){ //trx의 마지막 obj 찾기
        tmp_ptr = tmp_ptr->next;
        }
        while(tmp_ptr->prev != NULL){ //전부 free 해주기
            lock_t * free_obj = tmp_ptr;
            tmp_ptr = tmp_ptr->prev;
            tmp_ptr->next = NULL;
            free(free_obj);
            // print_trxM();
        }
        tar_trx->first_obj = NULL;
        free(tmp_ptr);
        // print_trxM();
    }

    //trxM에서 해당 trx 빼기
    if(tar_trx->prev != NULL){
        // printf("prev id : %d\n",tar_trx->prev->id);
        tar_trx->prev->next = tar_trx->next;
    }
    else{
        printf("prev is null\n");  //list의 첫번째라는 것
        if(tar_trx->next != NULL){
            tar_trx->next->prev = NULL;
            trxM->head_trx = tar_trx->next;
        }
        else{  //완전히 빈 리스트가 될때
            trxM->head_trx = NULL;
        }
    }

    if(tar_trx->next != NULL){
        // printf("next id : %d\n",tar_trx->next->id);
        tar_trx->next->prev = tar_trx->prev;
    }
    else{
        // printf("next is null\n");
        if(tar_trx->prev != NULL){  //list의 마지막 요소가 삭제될댸
            tar_trx->prev->next = NULL;
        }
        else{  //완전히 빈 리스트가 될때
            trxM->head_trx = NULL;
        }
    }

    free(tar_trx);

    return 1;
}

int add_obj_trx(int trx_id){
    lock_t * tmp_obj = (lock_t *)malloc(sizeof(lock_t));
    tmp_obj->a = count;
    tmp_obj->prev = NULL;
    tmp_obj->next = NULL;
    
    count += 1;

    trx * tar_trx = trx_find(trx_id);
    if(tar_trx == NULL){
        return 0;
    }
    lock_t * tmp_ptr = tar_trx->first_obj;
    if(tmp_ptr == NULL){
        tar_trx->first_obj = tmp_obj;
        return 1;
    }
    while(tmp_ptr->next != NULL){
        tmp_ptr = tmp_ptr->next;
    }
    tmp_ptr->next = tmp_obj;
    tmp_obj->prev = tmp_ptr;

    return 1;
}


int main(void){
    init_trxM();
    int ret = trx_begin();
    // printf("IN main, first trx id : %d\n",ret);
    ret = trx_begin();
    // printf("IN main, second trx id : %d\n",ret);
    ret = trx_begin();
    // printf("IN main, third trx id : %d\n",ret);
    ret = add_obj_trx(1);
    ret = add_obj_trx(1);
    ret = add_obj_trx(1);
    ret = add_obj_trx(2);
    ret = add_obj_trx(2);
    ret = add_obj_trx(3);
    print_trxM();
    ret = trx_commit(2);
    ret = trx_commit(1);
    ret = trx_commit(3);
    print_trxM();
    
    return 0;
}