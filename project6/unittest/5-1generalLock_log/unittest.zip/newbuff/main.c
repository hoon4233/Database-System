#include "bpt.h"

extern buffer * buff;
extern tManager * tableM;
extern page_t header;

#define FIND_NUM (100)

int count = -1;
pthread_mutex_t count_latch = PTHREAD_MUTEX_INITIALIZER;

void*
find_thread_func(void* arg)
{
    int id = pthread_self();
	char val[VALUE_SIZE];
    int tmp_count;
    printf("new find Thread id : %d\n",id);

    pthread_mutex_lock(&count_latch);
    count += 1;
    tmp_count = count;
    pthread_mutex_unlock(&count_latch);
    
    int ret = db_find(1,tmp_count, val);
    if(ret == 1){
        printf("find thread id : %d, fail\n",id);
        return NULL;
    }

    printf("thread id : %d, result : %s\n",id, val);
	return NULL;
}

int main(int argc, char ** argv){
    int ret = init_db(3);
    int tableNum = open_table(argv[1]);

    int table_id = 1;
    int key;
    int value[VALUE_SIZE];
    for(int i =0; i<FIND_NUM; i++){
        key = i;
        sprintf(value,"%d",i);
        ret = db_insert(table_id, key, value);
        // print_tree(1);
    }

    pthread_t find_thread[FIND_NUM];

    print_tree(1);
    // sleep(5);

    for(int i = 0; i<FIND_NUM; i++){
        pthread_create(&find_thread[i],0,find_thread_func,NULL);
    }

    for(int i = 0; i<FIND_NUM; i++){
        pthread_join(find_thread[i],NULL);
    }
    printf("count : %d\n",count);

    return 0;
    
}

// int main( int argc, char ** argv ) {
//     char instruction;
//     int64_t key;
//     char value[VALUE_SIZE];
//     int table_id;

//     int ret_int;
//     int ret;
//     int tableNum;
    
//     if(argc >= 2){
//         ret = init_db(100);
//         tableNum = open_table(argv[1]);
//     }
//     else{
//         ret = init_db(1000);
//         tableNum = open_table("sample.db");
//     }
    
//     table_id = 1;
//     for(int i =0; i<10; i++){
//         key = i;
//         sprintf(value,"%d",i);
//         ret = db_insert(table_id, key, value);
//         print_tree(table_id);
//     }
    

//     printf("> ");
//     while (scanf("%c", &instruction) != EOF) {
//         switch (instruction) {
//         case 'd':
//             scanf("%d %lldd", &table_id, &key);
//             ret_int = db_delete(table_id,key);
//             print_tree(table_id);
//             break;
//         case 'i': 
//             scanf("%d %lld %s", &table_id, &key, value);
//             ret_int = db_insert(table_id,key, value);
//             print_tree(table_id);
//             break;
//         case 'f':
//             scanf("%d %lld", &table_id, &key);
//             ret_int = db_find(table_id,key, value);
//             printf("find result : %s\n", value);
//             break;
        
//         case 'q':
//             while (getchar() != (int)'\n');
//             for(int i=1; i<10; i++){
//                 close_table(i);
//             }
//             shutdown_db();
//             return EXIT_SUCCESS;
//             break;

//         case 't':
//             scanf("%d", &table_id);
//             print_tree(table_id);
//             break;

//         case 'u':
//             scanf("%d %lld %s", &table_id, &key, value);
//             ret_int = db_update(table_id,key, value);
//             break;
            
//         default:
//             break;
//         }
//         while (getchar() != (int)'\n');
//         printf("> ");
//     }
//     printf("\n");
//     return EXIT_SUCCESS;
// }
