#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <pthread.h>

int count = 0;

typedef struct Gnode{
    int vertex;
    int * edge;
    int used_cnt;

    struct Gnode * next;
    struct Gnode * prev;
}Gnode;

typedef struct graphManager{
    Gnode * head_node;
    Gnode * tail_node;
}graphManager;

typedef struct visit{
    int vertex;
    int is_check;

    struct visit * next;
    struct visit * prev;
}visit;

typedef struct visitManager{
    visit * head;
    visit * tail;
}visitManager;

graphManager * graphM;
visitManager * visitM;

int * Gqueue;
int GqueueLen = 0;

pthread_mutex_t graph_latch = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t gqueue_latch = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t visit_latch = PTHREAD_MUTEX_INITIALIZER;

void init_graphM(void){
    graphM = (graphManager*)malloc(sizeof(graphManager));
    graphM->head_node = NULL;
    graphM->tail_node = NULL;
}

void init_visitM(void){
    visitM = (visitManager*)malloc(sizeof(visitManager));
    visitM->head = NULL;
    visitM->tail = NULL;

    Gnode * tmp_g = graphM->head_node;
    
    while(tmp_g != NULL){
        visit * tmp_v = (visit*)malloc(sizeof(visit));
        tmp_v->vertex = tmp_g->vertex;
        tmp_v->is_check = 0;
        tmp_v->next = NULL;
        tmp_v->prev = NULL;
        if(visitM->head == NULL){
            visitM->head = tmp_v;
            visitM->tail = tmp_v;
        }
        else{
            visitM->tail->next = tmp_v;
            tmp_v->prev = visitM->tail;
            visitM->tail = tmp_v;
        }
        tmp_g = tmp_g->next;
    }
}

void print_graphM(void){
    pthread_mutex_lock(&graph_latch);
    printf("Start print_graphM\n");
    Gnode * tmp_ptr = graphM->head_node;

    while(tmp_ptr != NULL){
        printf("node id : %d\n [  ",tmp_ptr->vertex);
        for(int i = 0; i < tmp_ptr->used_cnt; i++){
            printf("%d  ",tmp_ptr->edge[i]);
        }
        printf("]\n");
        tmp_ptr = tmp_ptr->next;
    }
    pthread_mutex_unlock(&graph_latch);
}

Gnode * Gnode_find(int tar_vertex){  //graph에서 해당 node 찾아줌
    Gnode * tmp_ptr = graphM->head_node;
    if(tmp_ptr == NULL){
        return NULL;
    }
    while(tmp_ptr != NULL){
        if(tmp_ptr->vertex == tar_vertex){
            return tmp_ptr;
        }
        tmp_ptr = tmp_ptr->next;
    }
    return NULL;
}

visit * visit_find(int tar_vertex){  //visitM에서 해당 visit 찾아줌
    visit * tmp_ptr = visitM->head;
    if(tmp_ptr == NULL){
        return NULL;
    }
    while(tmp_ptr != NULL){
        if(tmp_ptr->vertex == tar_vertex){
            return tmp_ptr;
        }
        tmp_ptr = tmp_ptr->next;
    }
    return NULL;
}

Gnode * add_vertex(int tar_vertex){  //graph에 vertex 추가, edge는 add_edge로
    // pthread_mutex_lock(&graph_latch);
	Gnode * tmp = (Gnode *)malloc(sizeof(Gnode));
    tmp->vertex = tar_vertex;
    tmp->edge = NULL;
    tmp->used_cnt = 0;

	tmp->prev = NULL;
	tmp->next = NULL;

	if(graphM->head_node == NULL){
		graphM->head_node = tmp;
		graphM->tail_node = tmp;
        
        // pthread_mutex_unlock(&graph_latch);
        return tmp;
	}

	Gnode * ori_tail = graphM->head_node;
	while(ori_tail->next){
		ori_tail = ori_tail->next;
	}
	ori_tail->next = tmp;
	tmp->prev = ori_tail;
	graphM->tail_node = tmp;

    // pthread_mutex_unlock(&graph_latch);
	return tmp;
}

void add_edge(int src, int dest){ //src가 dest를 기다림, graph에 edge추가, vertex는 add_vertex로
    // pthread_mutex_lock(&graph_latch);
    Gnode * tmp = Gnode_find(src);
    tmp->used_cnt += 1;
    tmp->edge = (int*)realloc(tmp->edge, sizeof(int)*tmp->used_cnt);
    tmp->edge[tmp->used_cnt-1] = dest;
    // pthread_mutex_unlock(&graph_latch);
}

void del_vertex(int tar_vertex){  //graph에서 해당 vertex와 해당 vertex로 들어오는 모든 edge 삭제
    // pthread_mutex_lock(&graph_latch);
    Gnode * tmp = graphM->head_node;
    while(tmp != NULL){  //delete edge
        for(int i = 0; i<tmp->used_cnt; i++){
            if(tmp->edge[i] == tar_vertex){
                if(tmp->used_cnt > 0){
                    tmp->edge[i] = tmp->edge[tmp->used_cnt-1];
                    tmp->used_cnt -= 1;
                }
                tmp->edge = (int *)realloc(tmp->edge,sizeof(int)*tmp->used_cnt);
            }
        }
        tmp = tmp->next;
    }

    Gnode * tar_node = Gnode_find(tar_vertex); //In graph, delete vertex 
    if(tar_node == graphM->head_node && graphM->tail_node){
        graphM->head_node = NULL;
        graphM->tail_node = NULL;
    }
    else if(tar_node == graphM->head_node){
        graphM->head_node = tar_node->next;
        if(tar_node->next){
            tar_node->next->prev = NULL;
        }
    }
    else if(tar_node == graphM->tail_node){
        graphM->tail_node = tar_node->prev;
        if(tar_node->prev){
            tar_node->prev->next = NULL;
        }
    }
    else{
        tar_node->prev->next = tar_node->next;
        tar_node->next->prev = tar_node->prev;
    }
    tar_node->next = NULL;
    tar_node->prev = NULL;
    // pthread_mutex_unlock(&graph_latch);
}


void Genqueue( int edge ) {  //graph에서 cycle 체크 할때 쓸 queue의 push
    
    if (GqueueLen == 0) {
        Gqueue = (int*)malloc(sizeof(int));
        GqueueLen += 1;
        Gqueue[GqueueLen-1] = edge;
    }

    else {
        GqueueLen += 1;
        Gqueue = (int*)realloc(Gqueue,sizeof(int)*GqueueLen);
        Gqueue[GqueueLen-1] = edge;
    }
}

int Gdequeue( void ) {  //graph에서 cycle 체크 할때 쓸 queue의 pop
    int ret_i = Gqueue[0];
    for(int i=0; i < (GqueueLen-1); i++){
        Gqueue[i] = Gqueue[i+1];
    }
    Gqueue[GqueueLen-1] = 0;
    GqueueLen -= 1;
    Gqueue = (int*)realloc(Gqueue,sizeof(int)*GqueueLen);

    return ret_i;
}


int check_cycle( int tar_vertex ){  //graph의 cycle 유무 체크, 해당 vertex로 돌아오는 사이클이 있는지만 확인
    // pthread_mutex_lock(&graph_latch);
    // pthread_mutex_lock(&visit_latch);
    // pthread_mutex_lock(&gqueue_latch);
    init_visitM();
    GqueueLen = 0;
    Genqueue(tar_vertex);
    while( GqueueLen != 0 ){
        int tmp_len = GqueueLen;
        for(int i = 0; i<tmp_len; i++){
            int tmp = Gdequeue();
            visit * tmp_v = visit_find(tmp);
            tmp_v->is_check = 1;
            Gnode * tmp_node = Gnode_find(tmp);
            for(int j = 0; j < tmp_node->used_cnt; j++){
                if(tmp_node->edge[j] == tar_vertex){
                    // pthread_mutex_unlock(&gqueue_latch);
                    // pthread_mutex_unlock(&visit_latch);
                    // pthread_mutex_unlock(&graph_latch);
                    free(Gqueue);
                    return 1;
                }
                visit * tmp_check = visit_find(tmp_node->edge[j]);
                if(tmp_check != NULL && tmp_check->is_check == 0){
                    Genqueue(tmp_node->edge[j]);
                }
            }
        }
    }
    // pthread_mutex_unlock(&gqueue_latch);
    // pthread_mutex_unlock(&visit_latch);
    // pthread_mutex_unlock(&graph_latch);
    free(Gqueue);
    return 0;
}

int detect_deadlock(int src_trx, int dest_trx){
	pthread_mutex_lock(&graph_latch);
	Gnode * v = Gnode_find(src_trx);
	if(v == NULL){
		v = add_vertex(src_trx);
	}
	add_edge(src_trx, dest_trx);
	
	int ret = check_cycle(src_trx);

	if(ret == 1){
		del_vertex(src_trx);
		pthread_mutex_unlock(&graph_latch);
		return 1;
	}
	pthread_mutex_unlock(&graph_latch);
	return 0;
}


int main(void){
    init_graphM();

    add_vertex(0);
    add_edge(0,2);

    // add_vertex(1);
    // add_edge(1,0);
    
    // add_vertex(2);
    // add_edge(2,1);
    // add_edge(2,2);

    print_graphM();

    int ret = detect_deadlock(0,1);
    printf("%d\n",ret);
    ret = detect_deadlock(2,1);
    printf("%d\n",ret);

    print_graphM();
    
    return 0;
}