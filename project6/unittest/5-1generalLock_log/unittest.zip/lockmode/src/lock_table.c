#include <lock_table.h>
// #define HASH_SIZE 5000
#define HASH_SIZE 10

int count = 0; //디버그용

Node * hash_table[HASH_SIZE];
pthread_mutex_t lock_table_latch = PTHREAD_MUTEX_INITIALIZER;


//trxM
trxManager * trxM;
pthread_mutex_t trx_table_latch = PTHREAD_MUTEX_INITIALIZER;


///////about hash
void print_hash_table()
{
	pthread_mutex_lock(&trx_table_latch);
	pthread_mutex_lock(&lock_table_latch);

	printf("\nPrint All hash data \n");
    for (int i = 0; i < HASH_SIZE; i++)
    {
        if (hash_table[i] != NULL)
        {
			printf("idx : %d \n",i);
			
            Node* node = hash_table[i];
            while (node->next)
            {
				// printf("%d, %lld //", node->lock_entry->tid, node->lock_entry->rid);
				lock_t * tmp = node->lock_entry->head;
				int count = 0;
				printf("%d, %lld. mode : ", node->lock_entry->tid, node->lock_entry->rid);
				while(tmp){
					count += 1;
					printf("%d ", tmp->mode);
					tmp = tmp->next;
				}
				// printf("%d, %lld // ", node->lock_entry->tid, node->lock_entry->rid);
				printf("   count : %d // \n",count);
                node = node->next;
            }
			lock_t * tmp = node->lock_entry->head;
			int count = 0;
			printf("%d, %lld. mode : ", node->lock_entry->tid, node->lock_entry->rid);
			while(tmp){
				count += 1;
				printf("%d ", tmp->mode);
				tmp = tmp->next;
			}
			// printf("%d, %lld // \n", node->lock_entry->tid, node->lock_entry->rid);
            // printf("%d, %lld, count : %d\n", node->lock_entry->tid, node->lock_entry->rid, count);
			printf("   count : %d // \n",count);
        }
    }
    printf("\n\n");

	pthread_mutex_unlock(&lock_table_latch);
	pthread_mutex_unlock(&trx_table_latch);
}

int hash_key(int table_id, int64_t record_id){
	char tid_s[50];  //int 최대값 2147483647, rid_s를 뒤에 붙일거니까
	char rid_s[25];  //int 64_t 최대값 9223372036854775807
	int ret = 0;

	sprintf(tid_s,"%d",table_id);
	sprintf(rid_s,"%lld",record_id);
	strcat(tid_s,rid_s);

	ret = atoi(tid_s)%HASH_SIZE;
	// ret = (table_id + record_id) % HASH_SIZE;

	return ret;
}

Node* hash_find(int table_id, int64_t record_id)
{
    int h_key = hash_key(table_id, record_id);
	
	if(h_key < 0){
		return NULL;
	}
    if (hash_table[h_key] == NULL)
        return NULL;

	Node* tmp = hash_table[h_key];
 
    if (tmp->lock_entry->tid == table_id && tmp->lock_entry->rid == record_id )
    {
        return tmp;
    }
    else
    {
        while (tmp->next)
        {
            
			if (tmp->next->lock_entry->tid == table_id && tmp->next->lock_entry->rid == record_id)
            {
                return tmp->next;
            }
            tmp = tmp->next;
        }
    }
    return  NULL;
}

Node * hash_insert(int table_id, int64_t record_id)
{
	Node * tmp_node = (Node *)malloc(sizeof(Node));
	tmp_node->lock_entry = (lock_e *)malloc(sizeof(lock_e));
	tmp_node->lock_entry->tid  = table_id;
	tmp_node->lock_entry->rid  = record_id;
	tmp_node->lock_entry->head  = NULL;
	tmp_node->lock_entry->tail  = NULL;
	tmp_node->next = NULL;

    int h_key = hash_key(table_id, record_id);
    if (hash_table[h_key] == NULL) //collision 안나면 그냥 넣어줌
    {
        hash_table[h_key] = tmp_node;
		// return tmp_node;
    }
    else //collision 나면 앞에 넣어줌
    {
		if(hash_find(table_id, record_id) == NULL){
			tmp_node->next = hash_table[h_key];
			hash_table[h_key] = tmp_node;
			// return tmp_node;
		}
    }
	return tmp_node;
}


////////about obj
lock_t * add_obj(lock_e * entry, int trx_id, int lock_mode){
	lock_t * tmp = (lock_t *)malloc(sizeof(lock_t));
	tmp->prev = NULL;
	tmp->next = NULL;
	tmp->sentinel = entry;
	
	int ret = pthread_cond_init(&tmp->cv,0);

	tmp->mode = lock_mode;
	tmp->trxnextlock = NULL; 
	tmp->trxprevlock = NULL;
	tmp->owner_id = trx_id;
	

	if(entry->head == NULL){
		entry->head = tmp;
		entry->tail = tmp;

		//add trx table
		ret = add_obj_trx(trx_id, tmp);
		if(ret == 1){
			return tmp;
		}
		return NULL;
	}

	lock_t * ori_tail = entry->head;
	while(ori_tail->next){
		ori_tail = ori_tail->next;
	}
	ori_tail->next = tmp;
	tmp->prev = ori_tail;
	entry->tail = tmp;
	
	//add trx table
	ret = add_obj_trx(trx_id, tmp);
	if(ret == 1){
		return tmp;
	}

	return NULL;
}

lock_t * del_obj(lock_t * obj){
	lock_e * entry = obj->sentinel;
	lock_t * tmp = obj->next;

	if(obj == entry->tail && obj == entry->head){
		entry->tail = NULL;
		entry->head = NULL;
	}

	else if(obj == entry->tail){
		entry->tail = obj->prev;
		if(obj->prev){
			obj->prev->next = NULL;
		}
	}
	else if (obj == entry->head){
		entry->head = obj->next;
		if(obj->next){
			obj->next->prev = NULL;
		}
	}
	else{
		obj->prev->next = obj->next;
		obj->next->prev = obj->prev;
	}


	obj->prev = NULL;
	obj->next = NULL;

	//trx table에서 삭제
	if(obj->trxprevlock != NULL){
		obj->trxprevlock->trxnextlock = NULL;
	}
	
	free(obj);
	return tmp;
}





//////about lock
int
init_lock_table()
{
	for(int i = 0; i<HASH_SIZE; i++){
		hash_table[i] = NULL;
	}

	return 0;
}

lock_t*
lock_acquire(int table_id, int64_t key, int trx_id, int lock_mode)
{
	pthread_mutex_lock(&trx_table_latch);
	pthread_mutex_lock(&lock_table_latch);
	lock_t * obj = NULL;
	Node * node = NULL;

	node = hash_find(table_id, key);
	
	if(node == NULL){
		count += 1; //for debug
		// printf("IN lock_acquire, before hash_insert\n");
		node = hash_insert(table_id, key);
		// printf("IN lock_acquire, after hash_insert\n");
	}
	
	//dead lock detection. deadlock 시 lock_table_latch, trx_table_latch 반납


	// printf("IN lock_acquire, before add_obj\n");
	obj = add_obj(node->lock_entry, trx_id, lock_mode);
	//add_obj_trx 랑 dead lock detection하기
	// printf("IN lock_acquire, before add_obj\n");

	if(obj == NULL){
		pthread_mutex_unlock(&lock_table_latch);
		pthread_mutex_unlock(&trx_table_latch);
		return (void*) 0;
	}

	lock_t * prev_obj = obj->prev;

	if(lock_mode == 0){  //s lock
		while(prev_obj != NULL){
			if(prev_obj->mode == 1 ){ //앞에 1개라도 x 있으면 기다리기
				pthread_t tmp_id = pthread_self();
				// printf("mod 0 before sleep id : %ud\n",tmp_id);
				// printf("table id : %d, key : %d\n",table_id,key);
				pthread_mutex_unlock(&lock_table_latch);
				pthread_cond_wait(&obj->cv,&trx_table_latch);
				pthread_mutex_lock(&lock_table_latch);
				// printf("mod 0 after sleep id : %ud\n",tmp_id);
				break;
			}
			prev_obj = prev_obj->prev;
		}
	}

	if(lock_mode == 1){  //x lock
		if(prev_obj != NULL){
			pthread_t tmp_id = pthread_self();
			// printf("mod 1 before sleep id : %ud\n",tmp_id);
			pthread_mutex_unlock(&lock_table_latch);
			pthread_cond_wait(&obj->cv,&trx_table_latch);
			pthread_mutex_lock(&lock_table_latch);
			// printf("mod 1 after sleep id : %ud\n",tmp_id);
		}
	}

	pthread_mutex_unlock(&lock_table_latch);
	pthread_mutex_unlock(&trx_table_latch);

	if(obj != NULL){
		return obj;
	}

	return (void*) 0;
}

int
lock_release(lock_t* lock_obj)
{
	// pthread_mutex_lock(&lock_table_latch);
	lock_t * next_obj = NULL;
	int now_mode = lock_obj->mode;

	// printf()

	// printf("IN lock_release, before del_obj\n");
	// print_hash_table();
	// printf("IN lock_release, before dle_obj\n");
	next_obj = del_obj(lock_obj);
	// printf("IN lock_release, after del_obj\n");
	// print_hash_table();
	// printf("IN lock_release, after del_obj\n");
	if(next_obj != NULL){
		// printf("IN lock_release, after del_obj\n");
		// print_hash_table();

		if(now_mode == 0){
			if( now_mode == next_obj->mode ){ //s lock(지운거) - s lock(다음거)
				// printf("s - s\n");
				// pthread_mutex_unlock(&lock_table_latch);
				return 0;
			}
			else{  //s lock - x lock
				if(next_obj->prev == NULL){
					// printf("s - x\n");
					pthread_cond_signal(&next_obj->cv);
					// pthread_mutex_unlock(&lock_table_latch);
					return 0;
				}
			}
			
		}

		if(now_mode == 1){
			if( now_mode == next_obj->mode ){ //x lock - x lock
				// printf("x - x\n");
				pthread_cond_signal(&next_obj->cv);
				// pthread_mutex_unlock(&lock_table_latch);
				return 0;
			}
			else{ //x lock - s lock
				// printf("x - s\n");
				while(next_obj != NULL && next_obj->mode != 1){
					pthread_cond_signal(&next_obj->cv);
					next_obj = next_obj->next;
				}
				// pthread_mutex_unlock(&lock_table_latch);
				return 0;
			}
		}


	}

	// printf("IN lock_release,(no next_obj) after del_obj\n");
	// print_hash_table();
	// pthread_mutex_unlock(&lock_table_latch);
	return 0;
}





//trxM

void init_trxM(void){
    trxM = (trxManager*)malloc(sizeof(trxManager));
    trxM->global_trx_id = 1;
    trxM->head_trx = NULL;
}

void print_trxM(void){
	pthread_mutex_lock(&trx_table_latch);
	pthread_mutex_lock(&lock_table_latch);

    printf("IN print_trxM, now global_trx_id : %d\n",trxM->global_trx_id);
    trx * tmp_ptr = trxM->head_trx;

    while(tmp_ptr != NULL){
        printf("trx id : %d\n",tmp_ptr->id);
        lock_t * tmp_ptr2 = tmp_ptr->first_obj;
        while(tmp_ptr2 != NULL){
            printf("%d  ",tmp_ptr2->mode);
            tmp_ptr2 = tmp_ptr2->next;
        }
        printf("\n\n");
        tmp_ptr = tmp_ptr->next;
    }

	pthread_mutex_unlock(&lock_table_latch);
	pthread_mutex_unlock(&trx_table_latch);
}

trx * trx_find(int trx_id){
    trx * tmp_ptr = trxM->head_trx;
    if(tmp_ptr == NULL){
        return NULL;
    }
    while(tmp_ptr != NULL){
        if(tmp_ptr->id == trx_id){
            return tmp_ptr;
        }
        tmp_ptr = tmp_ptr->next;
    }
    return NULL;
}

int trx_begin(void){
	pthread_mutex_lock(&trx_table_latch);

    trx * tmp_trx = (trx*)malloc(sizeof(trx));
    
    if(tmp_trx == NULL){
		pthread_mutex_unlock(&trx_table_latch);
        return 0;
    }

    tmp_trx->id = trxM->global_trx_id; //trx 만들기
    tmp_trx->first_obj = NULL;   
    tmp_trx->prev = NULL;
    tmp_trx->next =NULL;

    trxM->global_trx_id += 1;

    trx * tmp_ptr = trxM->head_trx; //trx를 trxM에 넣기
    
    if(tmp_ptr == NULL){ //trxM에 처음 trx를 넣는 경우
        trxM->head_trx = tmp_trx;
    }

    else{  //trxM에서 linked list 구조를 이용해 마지막에 넣어주는 경우
        while(tmp_ptr->next != NULL){
            tmp_ptr = tmp_ptr->next;
        }
        tmp_ptr->next = tmp_trx;
        tmp_trx->prev = tmp_ptr;
    }
	
	pthread_mutex_unlock(&trx_table_latch);
    return tmp_trx->id;
}

int trx_commit(int trx_id){
	pthread_mutex_lock(&trx_table_latch);
	pthread_mutex_lock(&lock_table_latch);

	int ret = 0;
	
    trx * tar_trx = trx_find(trx_id);
    // printf("IN trx_commit, trx_find succ, id : %d\n",tar_trx->id);
    if(tar_trx == NULL){
		pthread_mutex_unlock(&lock_table_latch);
		pthread_mutex_unlock(&trx_table_latch);
        return 0;
    }
    //lock release 전부 해주고 (trx의 lock obj 없애주기)
    lock_t * tmp_ptr = tar_trx->first_obj;
    if(tmp_ptr != NULL){  //obj를 가지고 있다면
        while(tmp_ptr->trxnextlock != NULL){ //trx의 마지막 obj 찾기
        tmp_ptr = tmp_ptr->trxnextlock;
        }

        while(tmp_ptr->trxprevlock != NULL){ //전부 free 해주기
            lock_t * free_obj = tmp_ptr;
            tmp_ptr = tmp_ptr->trxprevlock;
			ret = lock_release(free_obj);
            // print_trxM();
        }
        tar_trx->first_obj = NULL;
		ret = lock_release(tmp_ptr);
    }

    //trxM에서 해당 trx 빼기
    if(tar_trx->prev != NULL){
        // printf("prev id : %d\n",tar_trx->prev->id);
        tar_trx->prev->next = tar_trx->next;
    }
    else{
        // printf("prev is null\n");  //list의 첫번째라는 것
        if(tar_trx->next != NULL){
            tar_trx->next->prev = NULL;
            trxM->head_trx = tar_trx->next;
        }
        else{  //완전히 빈 리스트가 될때
            trxM->head_trx = NULL;
        }
    }

    if(tar_trx->next != NULL){
        // printf("next id : %d\n",tar_trx->next->id);
        tar_trx->next->prev = tar_trx->prev;
    }
    else{
        // printf("next is null\n");
        if(tar_trx->prev != NULL){  //list의 마지막 요소가 삭제될때
            tar_trx->prev->next = NULL;
        }
        else{  //완전히 빈 리스트가 될때
            trxM->head_trx = NULL;
        }
    }

    free(tar_trx);

	pthread_mutex_unlock(&lock_table_latch);
	pthread_mutex_unlock(&trx_table_latch);
    return 1;
}

int add_obj_trx(int trx_id, lock_t * lock_obj){
    trx * tar_trx = trx_find(trx_id);
    if(tar_trx == NULL){
        return 0;
    }
    lock_t * tmp_ptr = tar_trx->first_obj;
    if(tmp_ptr == NULL){
        tar_trx->first_obj = lock_obj;
		tar_trx->first_obj->trxnextlock = NULL;
		tar_trx->first_obj->trxprevlock = NULL;
        return 1;
    }
    while(tmp_ptr->trxnextlock != NULL){
        tmp_ptr = tmp_ptr->trxnextlock;
    }
    tmp_ptr->trxnextlock = lock_obj;
    
	lock_obj->trxprevlock = tmp_ptr;
	lock_obj->trxnextlock = NULL;

    return 1;
}