#ifndef __LOCK_TABLE_H__
#define __LOCK_TABLE_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <pthread.h>

//trxM
#include <stdlib.h>


typedef struct lock_t lock_t;

typedef struct lock_e{
	int tid;
	int64_t rid;
	lock_t * head;
	lock_t * tail;
}lock_e;

typedef struct Node
{
	lock_e * lock_entry;
	struct Node * next;
}Node;

struct lock_t {
	lock_t * prev;
	lock_t * next;
	lock_e * sentinel;
	pthread_cond_t cv;
	int mode;
	lock_t * trxnextlock;
	lock_t * trxprevlock;
	int owner_id;
};

//trxM
typedef struct trx{
    int id;
    lock_t * first_obj;
    struct trx * prev;
    struct trx * next;
}trx;

typedef struct trxManager{
    int global_trx_id;
    trx * head_trx;
}trxManager;



/* APIs for lock table */
int init_lock_table();
lock_t* lock_acquire(int table_id, int64_t key, int trx_id, int lock_mode);
int lock_release(lock_t* lock_obj);
void print_hash_table();
Node* hash_find(int table_id, int64_t record_id);
Node *  hash_insert(int table_id, int64_t record_id);


//trxM
void init_trxM(void);
void print_trxM(void);
trx * trx_find(int trx_id);
int trx_begin(void);
int trx_commit(int trx_id);
int add_obj_trx(int trx_id, lock_t * lock_obj);






#endif /* __LOCK_TABLE_H__ */
