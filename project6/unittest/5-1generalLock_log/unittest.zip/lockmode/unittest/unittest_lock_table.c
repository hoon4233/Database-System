#include <lock_table.h>

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

// #define TRANSFER_THREAD_NUMBER	(3)
// #define SCAN_THREAD_NUMBER		(2)
#define TRANSFER_THREAD_NUMBER	(3)
#define SCAN_THREAD_NUMBER		(2)

// #define TRANSFER_COUNT			(1000000)
// #define SCAN_COUNT				(1000000)

// #define TRANSFER_COUNT			(1000)
// #define SCAN_COUNT				(1000)
#define TRANSFER_COUNT			(1000)
#define SCAN_COUNT				(10)

#define TABLE_NUMBER			(3)
#define RECORD_NUMBER			(5)
#define INITIAL_MONEY			(100000)
#define MAX_MONEY_TRANSFERRED	(100)
#define SUM_MONEY				(TABLE_NUMBER * RECORD_NUMBER * INITIAL_MONEY)

/* This is shared data pretected by your lock table. */
int accounts[TABLE_NUMBER][RECORD_NUMBER];

pthread_mutex_t tmp_latch0 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t tmp_latch1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t tmp_latch2 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t tmp_latch3 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t tmp_latch4 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t tmp_latch5 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t tmp_latch6 = PTHREAD_MUTEX_INITIALIZER;

/*
 * This thread repeatedly transfers some money between accounts randomly.
 */
void*
transfer_thread_func(void* arg)
{
	lock_t*			source_lock;
	lock_t*			destination_lock;
	int				source_table_id;
	int				source_record_id;
	int				destination_table_id;
	int				destination_record_id;
	int				money_transferred;

	pthread_t tmp_id = pthread_self();
	printf("trans thread id : %ud\n",tmp_id);
	// int trxID = trx_begin();
	// if(trxID <= 0 ){
	// 	printf("trx_begin fail\n");
	// }
	sleep(1);

	for (int i = 0; i < TRANSFER_COUNT; i++) {
		if(i==550){
			printf("a\n");
			sleep(30);
		}
		/* Decide the source account and destination account for transferring. */
		source_table_id = rand() % TABLE_NUMBER;
		source_record_id = rand() % RECORD_NUMBER;
		destination_table_id = rand() % TABLE_NUMBER;
		destination_record_id = rand() % RECORD_NUMBER;
		int trxID = trx_begin();
		if(trxID <= 0 ){
			printf("trx_begin fail\n");
		}
		// source_table_id = 1;
		// source_record_id = 0;
		// destination_table_id = 1;
		// destination_record_id = 1;

		if ((source_table_id > destination_table_id) ||
				(source_table_id == destination_table_id &&
				 source_record_id >= destination_record_id)) {
			/* Descending order may invoke deadlock conditions, so avoid it. */
			continue;
		}
		
		/* Decide the amount of money transferred. */
		money_transferred = rand() % MAX_MONEY_TRANSFERRED;
		money_transferred = rand() % 2 == 0 ?
			(-1) * money_transferred : money_transferred;
		
		/* Acquire lock!! */
		// pthread_mutex_lock(&tmp_latch1);
		// printf("IN transfer thread id : %ud ,trx : %d, acq src tid : %d, rid : %d yet\n",tmp_id, i, source_table_id, source_record_id);
		source_lock = lock_acquire(source_table_id, source_record_id, trxID, 1);
		// printf("IN transfer thread id : %ud ,trx : %d, acq src tid : %d, rid : %d succ\n",tmp_id, i, source_table_id, source_record_id);
		// pthread_mutex_unlock(&tmp_latch1);

		/* withdraw */
		accounts[source_table_id][source_record_id] -= money_transferred;

		/* Acquire lock!! */
		// pthread_mutex_lock(&tmp_latch2);
		// printf("IN transfer thread id : %ud ,trx : %d, acq des tid : %d, rid : %d yet\n",tmp_id, i, destination_table_id, destination_record_id);
		destination_lock =
			lock_acquire(destination_table_id, destination_record_id, trxID, 1);
		// printf("IN transfer thread id : %ud ,trx : %d, acq des tid : %d, rid : %d succ\n",tmp_id, i, destination_table_id, destination_record_id);
		// pthread_mutex_unlock(&tmp_latch2);

		/* deposit */
		accounts[destination_table_id][destination_record_id]
			+= money_transferred;

		/* Release lock!! */
		// pthread_mutex_lock(&tmp_latch3);
		int ret = trx_commit(trxID);
		// printf("IN transfer thread id : %ud ,trx : %d done\n",tmp_id, i);
		// print_trxM();
		// print_hash_table();
		// pthread_mutex_unlock(&tmp_latch3);
		// lock_release(destination_lock);
		// lock_release(source_lock);
	}

	printf("Transfer thread is done.\n");

	return NULL;
}

// void*
// transfer_thread_func2(void* arg)
// {
// 	pthread_t tmp_id = pthread_self();
// 	printf("trans2 id : %ud\n",tmp_id);
// 	sleep(10);
// 	lock_t*			source_lock;
// 	lock_t*			destination_lock;
// 	int				source_table_id;
// 	int				source_record_id;
// 	int				destination_table_id;
// 	int				destination_record_id;
// 	int				money_transferred;

// 	for (int i = 0; i < TRANSFER_COUNT; i++) {
// 		/* Decide the source account and destination account for transferring. */
// 		// source_table_id = rand() % TABLE_NUMBER;
// 		// source_record_id = rand() % RECORD_NUMBER;
// 		// destination_table_id = rand() % TABLE_NUMBER;
// 		// destination_record_id = rand() % RECORD_NUMBER;
// 		source_table_id = 1;
// 		source_record_id = 1;
// 		destination_table_id = 2;
// 		destination_record_id = 2;

// 		if ((source_table_id > destination_table_id) ||
// 				(source_table_id == destination_table_id &&
// 				 source_record_id >= destination_record_id)) {
// 			/* Descending order may invoke deadlock conditions, so avoid it. */
// 			continue;
// 		}
		
// 		/* Decide the amount of money transferred. */
// 		money_transferred = rand() % MAX_MONEY_TRANSFERRED;
// 		money_transferred = rand() % 2 == 0 ?
// 			(-1) * money_transferred : money_transferred;
		
// 		/* Acquire lock!! */
// 		source_lock = lock_acquire(source_table_id, source_record_id, 1);

// 		/* withdraw */
// 		accounts[source_table_id][source_record_id] -= money_transferred;

// 		/* Acquire lock!! */
// 		destination_lock =
// 			lock_acquire(destination_table_id, destination_record_id, 1);

// 		/* deposit */
// 		accounts[destination_table_id][destination_record_id]
// 			+= money_transferred;

// 		/* Release lock!! */
// 		// int ret = trx_commit(trxID);
// 		lock_release(destination_lock);
// 		lock_release(source_lock);
// 	}

// 	printf("Transfer thread is done.\n");

// 	return NULL;
// }

/*
 * This thread repeatedly check the summation of all accounts.
 * Because the locking strategy is 2PL (2 Phase Locking), the summation must
 * always be consistent.
 */
void*
scan_thread_func(void* arg)
{
	int				sum_money;
	lock_t*			lock_array[TABLE_NUMBER][RECORD_NUMBER];
	pthread_t tmp_id = pthread_self();
	printf("scan thread id : %ud\n",tmp_id);
	// int trxID = trx_begin();
	// if(trxID <= 0 ){
	// 	printf("trx_begin fail\n");
	// }
	sleep(2);


	for (int i = 0; i < SCAN_COUNT; i++) {
		if(i==5){
			printf("hi\n");
		}
		int trxID = trx_begin();
		if(trxID <= 0 ){
			printf("trx_begin fail\n");
		}
		
		sum_money = 0;

		/* Iterate all accounts and summate the amount of money. */
		for (int table_id = 0; table_id < TABLE_NUMBER; table_id++) {
			for (int record_id = 0; record_id < RECORD_NUMBER; record_id++) {
				/* Acquire lock!! */
				// pthread_mutex_lock(&tmp_latch4);
				// printf("IN scan thread id : %ud ,trx : %d, acq tid : %d, rid : %d yet\n",tmp_id, i, table_id, record_id);
				lock_array[table_id][record_id] =
					lock_acquire(table_id, record_id, trxID, 0);
				// printf("IN scan thread id : %ud ,trx : %d, acq tid : %d, rid : %d succ\n",tmp_id, i, table_id, record_id);
				// pthread_mutex_unlock(&tmp_latch4);

				/* Summation. */
				sum_money += accounts[table_id][record_id];
			}
		}

		// pthread_mutex_lock(&tmp_latch3);
		int ret = trx_commit(trxID);
		// printf("IN scan thread id : %ud ,trx : %d done\n",tmp_id, i);
		// print_trxM();
		// print_hash_table();
		// pthread_mutex_unlock(&tmp_latch3);
		// for (int table_id = 0; table_id < TABLE_NUMBER; table_id++) {
		// 	for (int record_id = 0; record_id < RECORD_NUMBER; record_id++) {
		// 		/* Release lock!! */
		// 		lock_release(lock_array[table_id][record_id]);
		// 	}
		// }

		/* Check consistency. */
		if (sum_money != SUM_MONEY) {
			printf("Inconsistent state is detected!!!!!\n");
			printf("sum_money : %d\n", sum_money);
			printf("SUM_MONEY : %d\n", SUM_MONEY);
			return NULL;
		}
	}

	printf("Scan thread is done.\n");

	return NULL;
}

int main()
{
	pthread_t	transfer_threads[TRANSFER_THREAD_NUMBER];
	pthread_t	scan_threads[SCAN_THREAD_NUMBER];

	srand(time(NULL));

	/* Initialize accounts. */
	for (int table_id = 0; table_id < TABLE_NUMBER; table_id++) {
		for (int record_id = 0; record_id < RECORD_NUMBER; record_id++) {
			accounts[table_id][record_id] = INITIAL_MONEY;
		}
	}

	/* Initialize your lock table. */
	init_trxM();
	init_lock_table();

	/* thread create */
	for (int i = 0; i < TRANSFER_THREAD_NUMBER; i++) {
		pthread_create(&transfer_threads[i], 0, transfer_thread_func, NULL);
	}
	for (int i = 0; i < SCAN_THREAD_NUMBER; i++) {
		pthread_create(&scan_threads[i], 0, scan_thread_func, NULL);
	}
	// for (int i = 0; i < TRANSFER_THREAD_NUMBER/2; i++) {
	// 	pthread_create(&transfer_threads[i], 0, transfer_thread_func, NULL);
	// }
	// for (int i = TRANSFER_THREAD_NUMBER/2; i < TRANSFER_THREAD_NUMBER; i++) {
	// 	// pthread_create(&transfer_threads[i], 0, transfer_thread_func2, NULL);
	// 	pthread_create(&transfer_threads[i], 0, transfer_thread_func, NULL);
	// }
	// for (int i = 0; i < SCAN_THREAD_NUMBER; i++) {
	// 	pthread_create(&scan_threads[i], 0, scan_thread_func, NULL);
	// }

	/* thread join */
	for (int i = 0; i < 1; i++) {
		pthread_join(transfer_threads[i], NULL);
	}
	for (int i = 0; i < 1; i++) {
		pthread_join(scan_threads[i], NULL);
	}

	return 0;
}

